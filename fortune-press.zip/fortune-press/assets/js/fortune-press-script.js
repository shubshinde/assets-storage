console.log('FortunePlug loaded.')
