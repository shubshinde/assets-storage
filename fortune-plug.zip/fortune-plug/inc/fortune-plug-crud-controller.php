<?php


function something()
{
    
}
